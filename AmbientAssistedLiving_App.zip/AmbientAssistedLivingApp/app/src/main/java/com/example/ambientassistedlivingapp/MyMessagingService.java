package com.example.ambientassistedlivingapp;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class MyMessagingService  extends FirebaseMessagingService {
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        showNotification(remoteMessage.getFrom(),remoteMessage.getNotification().getTitle(),remoteMessage.getNotification().getBody());


    }
    public void showNotification(String topic,String title,String message){
        NotificationCompat.Builder builder=new NotificationCompat.Builder(this,"MyNotification")
                .setContentTitle(title)
                .setAutoCancel(true)
                .setContentText(message);
        NotificationManagerCompat manager=NotificationManagerCompat.from(this);
        builder.setSmallIcon(R.drawable.ic_launcher_background);
            manager.notify(999,builder.build());
    }
}
